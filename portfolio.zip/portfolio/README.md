# Portfolio website + private Admin Dashboard

Public site at `/`, private dashboard at `/admin`. All content (text, images, videos, links) lives in Supabase, so you never edit code to update the site.

## One-time setup (about 15 minutes)

### 1. Create the Supabase project
1. Go to supabase.com, sign up, and click **New project**.
2. Open **SQL Editor** and paste in `supabase/schema.sql`.
   **Before running:** change `YOUR_EMAIL@example.com` (near the top) to the email you will log in with.
3. Click **Run**. This creates the tables, the `media` storage bucket and all security rules.

### 2. Create your admin login
1. **Authentication → Users → Add user → Create new user.**
2. Enter the same email you put in the SQL, choose a strong password, and tick **Auto Confirm User**.
3. **Authentication → Sign In / Providers → Email:** turn **off** "Allow new users to sign up".
   (Even if left on, strangers still cannot access anything: only the email listed in the `admins` table passes the security rules.)

### 3. Connect the website
1. **Project Settings → API.** Copy the **Project URL** and the **anon / publishable** key.
2. Put them in `js/config.js`.
   Never use the `service_role` / secret key anywhere in this project.

### 4. Deploy (free)
Any static host works. Easiest options:
- **Netlify:** drag the whole `portfolio` folder onto app.netlify.com/drop.
- **Vercel / Cloudflare Pages / GitHub Pages:** upload the folder, no build command, output directory = the folder root.

Then open `https://your-site/admin`, log in, and start managing.

## Using the dashboard
- **Videos:** upload from your computer, add a thumbnail, title, description, category, and publish or hide. Use ▲ ▼ to reorder.
- **Projects:** add projects with a cover image plus several images/videos.
- **Categories:** add, rename or delete (UGC Videos, Reel Edits, Graphic Design are pre-created).
- **Website Content:** name, profile picture, hero heading/subtitle, button text, About Me, experience.
- **Social & Contact:** YouTube, TikTok, Instagram, WhatsApp, email, phone.
- **Account:** change your password.

Changes appear on the public site as soon as you save (just refresh the page).

## Security summary
- Only the public `anon` key is in the frontend. It can only do what the database rules allow.
- Row Level Security: visitors can read published content only; only the email in `admins` can add, edit or delete anything, including files in storage.
- Uploads go straight to Supabase Storage with your logged-in session token.

## Good to know
- **Upload size:** Supabase's free plan limits each file to 50 MB. Compress long videos (HandBrake, CapCut export at 1080p) or raise the limit under Storage → Settings on a paid plan.
- Deleting a video/project also deletes its files from storage.
- Browsers cache images; if a replaced picture looks old, hard-refresh.
