-- =====================================================================
-- Portfolio CMS schema  |  Run this ONCE in Supabase > SQL Editor
-- Safe to re-run (it drops and recreates policies).
-- =====================================================================

-- 1) WHO IS THE OWNER -------------------------------------------------
-- CHANGE THE EMAIL BELOW to the email you use to log in at /admin.
create table if not exists public.admins (
  email text primary key
);
insert into public.admins (email) values ('YOUR_EMAIL@example.com')
on conflict do nothing;

create or replace function public.is_admin()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.admins
    where lower(email) = lower(coalesce(auth.jwt() ->> 'email', ''))
  );
$$;

-- 2) TABLES -----------------------------------------------------------
create table if not exists public.site_settings (
  id int primary key default 1 check (id = 1),
  site_name text default 'Your Name',
  profile_image_url text,
  hero_heading text default 'I create scroll-stopping videos & designs',
  hero_subtitle text default 'UGC videos, reel edits and graphic design for brands and creators.',
  hero_button_text text default 'View My Work',
  contact_button_text text default 'Hire Me',
  about_title text default 'About Me',
  about_text text default 'Write something about yourself from the admin dashboard.',
  experience jsonb not null default '[]'::jsonb,
  contact_phone text,
  contact_location text,
  email text,
  youtube_url text,
  tiktok_url text,
  instagram_url text,
  whatsapp_number text,
  updated_at timestamptz default now()
);
insert into public.site_settings (id) values (1) on conflict do nothing;

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  sort_order int not null default 0
);
insert into public.categories (name, sort_order) values
  ('UGC Videos', 1), ('Reel Edits', 2), ('Graphic Design', 3)
on conflict do nothing;

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text default '',
  category text,
  video_url text not null,
  thumbnail_url text,
  published boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text default '',
  category text,
  cover_image_url text,
  media jsonb not null default '[]'::jsonb,   -- [{type:'image'|'video', url:'...'}]
  published boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

-- 3) ROW LEVEL SECURITY ----------------------------------------------
alter table public.admins        enable row level security;
alter table public.site_settings enable row level security;
alter table public.categories    enable row level security;
alter table public.videos        enable row level security;
alter table public.projects      enable row level security;

drop policy if exists "admins read self"        on public.admins;
drop policy if exists "settings public read"    on public.site_settings;
drop policy if exists "settings admin write"    on public.site_settings;
drop policy if exists "categories public read"  on public.categories;
drop policy if exists "categories admin write"  on public.categories;
drop policy if exists "videos public read"      on public.videos;
drop policy if exists "videos admin write"      on public.videos;
drop policy if exists "projects public read"    on public.projects;
drop policy if exists "projects admin write"    on public.projects;

-- an admin may see only their own row (used by the login check)
create policy "admins read self" on public.admins
  for select to authenticated
  using (lower(email) = lower(coalesce(auth.jwt() ->> 'email', '')));

create policy "settings public read" on public.site_settings for select using (true);
create policy "settings admin write" on public.site_settings
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "categories public read" on public.categories for select using (true);
create policy "categories admin write" on public.categories
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- visitors see only published items; the admin sees everything
create policy "videos public read" on public.videos
  for select using (published = true or public.is_admin());
create policy "videos admin write" on public.videos
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "projects public read" on public.projects
  for select using (published = true or public.is_admin());
create policy "projects admin write" on public.projects
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- 4) STORAGE (public-read bucket, admin-only write) -------------------
insert into storage.buckets (id, name, public)
values ('media', 'media', true)
on conflict (id) do update set public = true;

drop policy if exists "media public read"   on storage.objects;
drop policy if exists "media admin insert"  on storage.objects;
drop policy if exists "media admin update"  on storage.objects;
drop policy if exists "media admin delete"  on storage.objects;

create policy "media public read" on storage.objects
  for select using (bucket_id = 'media');
create policy "media admin insert" on storage.objects
  for insert to authenticated with check (bucket_id = 'media' and public.is_admin());
create policy "media admin update" on storage.objects
  for update to authenticated using (bucket_id = 'media' and public.is_admin());
create policy "media admin delete" on storage.objects
  for delete to authenticated using (bucket_id = 'media' and public.is_admin());
