// Paste your Supabase values here (Supabase > Project Settings > API).
// Use ONLY the "Project URL" and the "anon / publishable" key.
// NEVER paste the "service_role" / secret key anywhere in this project.
window.PORTFOLIO_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT-ID.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-ANON-PUBLIC-KEY"
};
