(function () {
  const cfg = window.PORTFOLIO_CONFIG || {};
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const safeUrl = (u) => (/^https?:\/\//i.test(u || '') ? u : '');

  $('year').textContent = new Date().getFullYear();

  if (!cfg.SUPABASE_URL || cfg.SUPABASE_URL.includes('YOUR-PROJECT')) {
    const n = $('setupNotice');
    n.hidden = false;
    n.textContent = 'Setup needed: add your Supabase URL and anon key in js/config.js';
    return;
  }

  const sb = supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
  let videos = [], projects = [], active = 'All';

  async function load() {
    const [s, c, v, p] = await Promise.all([
      sb.from('site_settings').select('*').eq('id', 1).maybeSingle(),
      sb.from('categories').select('*').order('sort_order'),
      sb.from('videos').select('*').eq('published', true).order('sort_order').order('created_at', { ascending: false }),
      sb.from('projects').select('*').eq('published', true).order('sort_order').order('created_at', { ascending: false })
    ]);
    if (s.error || v.error) {
      const n = $('setupNotice');
      n.hidden = false;
      n.textContent = 'Could not load content. Did you run supabase/schema.sql?';
      return;
    }
    videos = v.data || [];
    projects = p.data || [];
    renderSettings(s.data || {});
    renderChips(c.data || []);
    renderVideos();
    renderProjects();
  }

  function renderSettings(s) {
    const name = s.site_name || 'Portfolio';
    document.title = name + ' | Portfolio';
    $('navName').textContent = name;
    $('footName').textContent = name;
    $('heroHeading').textContent = s.hero_heading || '';
    $('heroSubtitle').textContent = s.hero_subtitle || '';
    $('heroBtn').textContent = s.hero_button_text || 'View My Work';
    $('contactBtn').textContent = s.contact_button_text || 'Contact';
    if (s.profile_image_url) {
      $('profileImg').src = s.profile_image_url;
      $('profileImg').alt = name;
      $('profileImg').hidden = false;
    }
    $('aboutTitle').textContent = s.about_title || 'About Me';
    $('aboutText').textContent = s.about_text || '';

    const exp = Array.isArray(s.experience) ? s.experience : [];
    $('expWrap').hidden = !exp.length;
    $('expList').innerHTML = exp.map((e) => `
      <div class="item"><b>${esc(e.role)}${e.company ? ' · ' + esc(e.company) : ''}</b>
      <small>${esc(e.period)}</small><p>${esc(e.description)}</p></div>`).join('');

    const contacts = [];
    if (s.email) contacts.push(`<a href="mailto:${esc(s.email)}">✉ ${esc(s.email)}</a>`);
    if (s.contact_phone) contacts.push(`<a href="tel:${esc(s.contact_phone)}">☎ ${esc(s.contact_phone)}</a>`);
    if (s.whatsapp_number) contacts.push(`<a target="_blank" rel="noopener" href="https://wa.me/${esc(String(s.whatsapp_number).replace(/\D/g, ''))}">WhatsApp</a>`);
    if (s.contact_location) contacts.push(`<span style="padding:11px 22px;color:var(--muted)">📍 ${esc(s.contact_location)}</span>`);
    $('contactList').innerHTML = contacts.join('');

    const soc = [['YouTube', s.youtube_url], ['TikTok', s.tiktok_url], ['Instagram', s.instagram_url]]
      .filter(([, u]) => safeUrl(u))
      .map(([n, u]) => `<a target="_blank" rel="noopener" href="${esc(u)}">${n}</a>`);
    $('socials').innerHTML = soc.join('');
  }

  function renderChips(cats) {
    const names = ['All', ...cats.map((c) => c.name)];
    $('chips').innerHTML = names.map((n) => `<button class="chip${n === active ? ' on' : ''}" data-c="${esc(n)}">${esc(n)}</button>`).join('');
    $('chips').onclick = (e) => {
      const b = e.target.closest('.chip');
      if (!b) return;
      active = b.dataset.c;
      document.querySelectorAll('.chip').forEach((x) => x.classList.toggle('on', x === b));
      renderVideos();
    };
  }

  function thumbHtml(v) {
    const media = v.thumbnail_url
      ? `<img loading="lazy" src="${esc(v.thumbnail_url)}" alt="${esc(v.title)}">`
      : `<video muted preload="metadata" src="${esc(v.video_url)}#t=0.5"></video>`;
    return `<div class="thumb">${media}<div class="play"><span>▶</span></div></div>`;
  }

  function renderVideos() {
    const list = videos.filter((v) => active === 'All' || v.category === active);
    $('videoEmpty').hidden = list.length > 0;
    $('videoGrid').innerHTML = list.map((v) => `
      <article class="card" data-v="${esc(v.id)}">${thumbHtml(v)}
        <div class="meta"><span class="tag">${esc(v.category || '')}</span>
        <h3>${esc(v.title)}</h3><p>${esc(v.description)}</p></div></article>`).join('');
  }

  function renderProjects() {
    $('projects').hidden = !projects.length;
    $('navProjects').hidden = !projects.length;
    $('projectGrid').innerHTML = projects.map((p) => {
      const first = (p.media || []).find((m) => m.type === 'image');
      const cover = p.cover_image_url || (first && first.url);
      const img = cover ? `<img loading="lazy" src="${esc(cover)}" alt="${esc(p.title)}">` : '';
      return `<article class="card" data-p="${esc(p.id)}"><div class="thumb" style="aspect-ratio:4/3">${img}</div>
        <div class="meta"><span class="tag">${esc(p.category || '')}</span><h3>${esc(p.title)}</h3><p>${esc(p.description)}</p></div></article>`;
    }).join('');
  }

  function openViewer(html) {
    $('viewerBody').innerHTML = html;
    $('viewer').hidden = false;
    document.body.style.overflow = 'hidden';
  }
  function closeViewer() {
    $('viewer').hidden = true;
    $('viewerBody').innerHTML = '';
    document.body.style.overflow = '';
  }
  $('viewerClose').onclick = closeViewer;
  $('viewer').onclick = (e) => { if (e.target.id === 'viewer') closeViewer(); };
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeViewer(); });

  $('videoGrid').onclick = (e) => {
    const c = e.target.closest('[data-v]');
    if (!c) return;
    const v = videos.find((x) => x.id === c.dataset.v);
    if (!v) return;
    openViewer(`<video controls autoplay playsinline src="${esc(v.video_url)}"></video><h3>${esc(v.title)}</h3><p>${esc(v.description)}</p>`);
  };
  $('projectGrid').onclick = (e) => {
    const c = e.target.closest('[data-p]');
    if (!c) return;
    const p = projects.find((x) => x.id === c.dataset.p);
    if (!p) return;
    const media = (p.media || []).map((m) => m.type === 'video'
      ? `<video controls playsinline src="${esc(m.url)}"></video>`
      : `<img src="${esc(m.url)}" alt="">`).join('');
    openViewer(`${media}<h3>${esc(p.title)}</h3><p>${esc(p.description)}</p>`);
  };

  load();
})();
