(function () {
  'use strict';
  const cfg = window.PORTFOLIO_CONFIG || {};
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const isUrl = (u) => !u || /^https?:\/\//i.test(u);

  if (!cfg.SUPABASE_URL || cfg.SUPABASE_URL.includes('YOUR-PROJECT')) {
    const n = $('#setupNotice');
    n.hidden = false;
    n.textContent = 'Setup needed: add your Supabase URL and anon key in js/config.js, then redeploy.';
    return;
  }
  const sb = supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);

  let cats = [];

  /* ---------- helpers ---------- */
  function toast(msg, type) {
    const t = document.createElement('div');
    t.className = 'toast ' + (type || 'ok');
    t.textContent = msg;
    $('#toasts').appendChild(t);
    setTimeout(() => t.remove(), type === 'err' ? 6000 : 3000);
  }
  const errMsg = (e) => (e && (e.message || e.error_description)) || 'Something went wrong';

  function storagePath(url) {
    const m = String(url || '').split('/storage/v1/object/public/media/');
    return m[1] ? decodeURIComponent(m[1].split('?')[0]) : null;
  }
  async function removeFiles(urls) {
    const paths = (urls || []).map(storagePath).filter(Boolean);
    if (paths.length) { try { await sb.storage.from('media').remove(paths); } catch (e) { /* ignore */ } }
  }

  async function uploadFile(file, folder, onProgress) {
    const { data } = await sb.auth.getSession();
    const session = data.session;
    if (!session) throw new Error('Session expired. Please log in again.');
    const ext = (file.name.split('.').pop() || 'bin').toLowerCase().replace(/[^a-z0-9]/g, '');
    const path = `${folder}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    await new Promise((resolve, reject) => {
      const x = new XMLHttpRequest();
      x.open('POST', `${cfg.SUPABASE_URL}/storage/v1/object/media/${path}`);
      x.setRequestHeader('Authorization', 'Bearer ' + session.access_token);
      x.setRequestHeader('apikey', cfg.SUPABASE_ANON_KEY);
      x.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
      x.setRequestHeader('Cache-Control', 'max-age=31536000');
      x.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100)); };
      x.onload = () => {
        if (x.status < 300) return resolve();
        let m = 'Upload failed (' + x.status + ')';
        try { const j = JSON.parse(x.responseText); m = j.message || j.error || m; } catch (e) { /* ignore */ }
        if (x.status === 413) m = 'File is too large for your Supabase upload limit.';
        reject(new Error(m));
      };
      x.onerror = () => reject(new Error('Network error during upload'));
      x.send(file);
    });
    return sb.storage.from('media').getPublicUrl(path).data.publicUrl;
  }

  function modal(html) {
    const bg = document.createElement('div');
    bg.className = 'modal-bg';
    bg.innerHTML = `<div class="modal">${html}</div>`;
    $('#modalRoot').appendChild(bg);
    return bg;
  }

  function busy(form, d) {
    form.dataset.busy = Math.max(0, (+form.dataset.busy || 0) + d);
    const b = form.querySelector('.save');
    if (b) b.disabled = +form.dataset.busy > 0;
  }

  function uploadField(o) {
    return `<div class="upl" data-name="${o.name}" data-folder="${o.folder}" data-kind="${o.kind}">
      <span>${o.label}</span>
      <input type="hidden" name="${o.name}" value="${esc(o.url || '')}">
      <input type="file" accept="${o.accept}">
      <div class="bar"><i></i></div><small class="status"></small><div class="preview"></div></div>`;
  }

  function wireUploads(form) {
    form._new = form._new || [];
    form._old = form._old || [];
    form.querySelectorAll('.upl[data-name]').forEach((box) => {
      const hidden = box.querySelector('input[type=hidden]');
      const file = box.querySelector('input[type=file]');
      const bar = box.querySelector('.bar i');
      const status = box.querySelector('.status');
      const prev = box.querySelector('.preview');
      const draw = () => {
        const u = hidden.value;
        if (!u) { prev.innerHTML = ''; return; }
        prev.innerHTML = box.dataset.kind === 'video'
          ? `<video controls preload="metadata" src="${esc(u)}"></video>`
          : `<img src="${esc(u)}" alt="">`;
      };
      draw();
      file.onchange = async () => {
        const f = file.files[0];
        if (!f) return;
        busy(form, 1);
        try {
          status.textContent = 'Uploading… 0%';
          bar.style.width = '0';
          const old = hidden.value;
          const u = await uploadFile(f, box.dataset.folder, (p) => { bar.style.width = p + '%'; status.textContent = `Uploading… ${p}%`; });
          if (old) form._old.push(old);
          form._new.push(u);
          hidden.value = u;
          status.textContent = 'Uploaded ✓';
          draw();
        } catch (e) {
          status.textContent = 'Upload failed';
          bar.style.width = '0';
          toast(errMsg(e), 'err');
        } finally {
          busy(form, -1);
          file.value = '';
        }
      };
    });
  }

  function closeForm(bg, form, saved) {
    if (saved) removeFiles(form._old);
    else removeFiles(form._new);
    bg.remove();
  }

  async function loadCats() {
    const { data } = await sb.from('categories').select('*').order('sort_order');
    cats = data || [];
  }
  function catOptions(current) {
    const names = cats.map((c) => c.name);
    if (current && !names.includes(current)) names.push(current);
    return names.map((n) => `<option ${n === current ? 'selected' : ''}>${esc(n)}</option>`).join('');
  }

  async function saveSettings(patch) {
    const { error } = await sb.from('site_settings').upsert({ id: 1, ...patch, updated_at: new Date().toISOString() });
    if (error) throw error;
  }
  async function getSettings() {
    const { data } = await sb.from('site_settings').select('*').eq('id', 1).maybeSingle();
    return data || {};
  }

  /* ---------- auth ---------- */
  async function isAdmin() {
    const { data } = await sb.from('admins').select('email').maybeSingle();
    return !!data;
  }
  function showLogin(msg) {
    $('#appView').hidden = true;
    $('#loginView').hidden = false;
    $('#loginMsg').textContent = msg || '';
  }
  async function showApp() {
    $('#loginView').hidden = true;
    $('#appView').hidden = false;
    await loadCats();
    route();
  }

  $('#loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    const btn = f.querySelector('button');
    btn.disabled = true; btn.textContent = 'Signing in…';
    $('#loginMsg').textContent = '';
    try {
      const { error } = await sb.auth.signInWithPassword({ email: f.email.value.trim(), password: f.password.value });
      if (error) throw error;
      if (!(await isAdmin())) {
        await sb.auth.signOut();
        throw new Error('This account is not allowed to access the dashboard.');
      }
      f.reset();
      await showApp();
    } catch (err) {
      $('#loginMsg').textContent = errMsg(err);
    } finally {
      btn.disabled = false; btn.textContent = 'Sign in';
    }
  });

  $('#logoutBtn').onclick = async () => { await sb.auth.signOut(); showLogin(); };
  sb.auth.onAuthStateChange((ev) => { if (ev === 'SIGNED_OUT') showLogin(); });

  /* ---------- router ---------- */
  const pages = {
    dashboard: ['Dashboard', pageDashboard],
    videos: ['Videos', pageVideos],
    projects: ['Projects', pageProjects],
    categories: ['Categories', pageCategories],
    content: ['Website Content', pageContent],
    social: ['Social & Contact', pageSocial],
    account: ['Account', pageAccount]
  };
  async function route() {
    const key = (location.hash || '#dashboard').slice(1);
    const [title, fn] = pages[key] || pages.dashboard;
    $('#pageTitle').textContent = title;
    document.querySelectorAll('#menu a').forEach((a) => a.classList.toggle('on', a.dataset.p === (pages[key] ? key : 'dashboard')));
    closeMenu();
    $('#page').innerHTML = '<p class="empty">Loading…</p>';
    try { await fn(); } catch (e) { $('#page').innerHTML = `<p class="empty">Error: ${esc(errMsg(e))}</p>`; }
  }
  window.addEventListener('hashchange', () => { if (!$('#appView').hidden) route(); });

  const openMenu = () => { $('#side').classList.add('open'); $('#scrim').classList.add('open'); };
  const closeMenu = () => { $('#side').classList.remove('open'); $('#scrim').classList.remove('open'); };
  $('#burger').onclick = openMenu;
  $('#scrim').onclick = closeMenu;

  /* ---------- dashboard ---------- */
  async function pageDashboard() {
    const [v, p, pub, recent] = await Promise.all([
      sb.from('videos').select('*', { count: 'exact', head: true }),
      sb.from('projects').select('*', { count: 'exact', head: true }),
      sb.from('videos').select('*', { count: 'exact', head: true }).eq('published', true),
      sb.from('videos').select('*').order('created_at', { ascending: false }).limit(5)
    ]);
    const rec = recent.data || [];
    $('#page').innerHTML = `
      <div class="stats">
        <div class="stat"><b>${v.count || 0}</b><span>Total videos</span></div>
        <div class="stat"><b>${pub.count || 0}</b><span>Published videos</span></div>
        <div class="stat"><b>${p.count || 0}</b><span>Portfolio projects</span></div>
      </div>
      <div class="panel"><h3>Quick actions</h3><div class="row">
        <a class="btn primary" href="#videos" data-quick="video">＋ Upload video</a>
        <a class="btn" href="#projects" data-quick="project">＋ Add project</a>
        <a class="btn" href="#content">Edit website text</a>
        <a class="btn" href="#social">Update social links</a>
        <a class="btn" href="/" target="_blank" rel="noopener">View website</a>
      </div></div>
      <div class="panel"><h3>Recent uploads</h3><div class="list">
        ${rec.length ? rec.map((x) => `<div class="item">${thumbEl(x.thumbnail_url, x.video_url)}
          <div class="info"><b>${esc(x.title)}</b><small>${esc(x.category || '')} · ${new Date(x.created_at).toLocaleDateString()}</small></div>
          <span class="badge ${x.published ? 'on' : 'off'}">${x.published ? 'Published' : 'Hidden'}</span></div>`).join('')
          : '<p class="empty">No videos uploaded yet.</p>'}
      </div></div>`;
    $('#page').querySelectorAll('[data-quick]').forEach((a) => a.addEventListener('click', () => { sessionStorage.setItem('quick', a.dataset.quick); }));
  }

  function thumbEl(thumb, video) {
    if (thumb) return `<img class="thumb" src="${esc(thumb)}" alt="">`;
    if (video) return `<video class="thumb" muted preload="metadata" src="${esc(video)}#t=0.5"></video>`;
    return '<div class="thumb"></div>';
  }

  /* ---------- generic list page (videos & projects) ---------- */
  async function listPage(o) {
    await loadCats();
    const { data, error } = await sb.from(o.table).select('*').order('sort_order').order('created_at', { ascending: false });
    if (error) throw error;
    const list = data || [];
    $('#page').innerHTML = `
      <div class="row between" style="margin-bottom:16px">
        <span class="hint">${list.length} ${o.plural}. Use ▲ ▼ to change the order shown on your website.</span>
        <button class="btn primary" id="addBtn">＋ Add ${o.singular}</button>
      </div>
      <div class="panel list">
        ${list.length ? list.map((it, i) => `<div class="item" data-id="${it.id}">
          ${o.thumb(it)}
          <div class="info"><b>${esc(it.title)}</b><small>${esc(it.category || 'No category')}</small></div>
          <span class="badge ${it.published ? 'on' : 'off'}">${it.published ? 'Published' : 'Hidden'}</span>
          <div class="actions">
            <button class="btn sm" data-a="up" ${i === 0 ? 'disabled' : ''} title="Move up">▲</button>
            <button class="btn sm" data-a="down" ${i === list.length - 1 ? 'disabled' : ''} title="Move down">▼</button>
            <button class="btn sm" data-a="pub">${it.published ? 'Unpublish' : 'Publish'}</button>
            <button class="btn sm" data-a="edit">Edit</button>
            <button class="btn sm danger" data-a="del">Delete</button>
          </div></div>`).join('') : `<p class="empty">Nothing here yet. Click “Add ${o.singular}” to start.</p>`}
      </div>`;
    const reload = () => route();
    $('#addBtn').onclick = () => o.form(null, reload);
    $('#page .list').onclick = async (e) => {
      const b = e.target.closest('button[data-a]');
      if (!b) return;
      const row = b.closest('.item');
      const idx = list.findIndex((x) => x.id === row.dataset.id);
      const it = list[idx];
      const a = b.dataset.a;
      try {
        if (a === 'edit') return o.form(it, reload);
        if (a === 'pub') {
          const { error: er } = await sb.from(o.table).update({ published: !it.published }).eq('id', it.id);
          if (er) throw er;
          toast(it.published ? 'Hidden from website' : 'Published on website');
          return reload();
        }
        if (a === 'up' || a === 'down') {
          const j = idx + (a === 'up' ? -1 : 1);
          if (j < 0 || j >= list.length) return;
          [list[idx], list[j]] = [list[j], list[idx]];
          const res = await Promise.all(list.map((x, i) => (x.sort_order !== i ? sb.from(o.table).update({ sort_order: i }).eq('id', x.id) : null)).filter(Boolean));
          const bad = res.find((r) => r.error);
          if (bad) throw bad.error;
          toast('Order updated');
          return reload();
        }
        if (a === 'del') {
          if (!confirm(`Delete “${it.title}”? This cannot be undone.`)) return;
          const { error: er } = await sb.from(o.table).delete().eq('id', it.id);
          if (er) throw er;
          await removeFiles(o.files(it));
          toast(o.singular[0].toUpperCase() + o.singular.slice(1) + ' deleted');
          return reload();
        }
      } catch (err) { toast(errMsg(err), 'err'); }
    };
    const quick = sessionStorage.getItem('quick');
    if (quick === o.singular) { sessionStorage.removeItem('quick'); o.form(null, reload); }
  }

  async function nextTopOrder(table) {
    const { data } = await sb.from(table).select('sort_order').order('sort_order').limit(1);
    return data && data.length ? data[0].sort_order - 1 : 0;
  }

  /* ---------- videos ---------- */
  function pageVideos() {
    return listPage({
      table: 'videos', singular: 'video', plural: 'videos',
      thumb: (v) => thumbEl(v.thumbnail_url, v.video_url),
      files: (v) => [v.video_url, v.thumbnail_url],
      form: videoForm
    });
  }

  function videoForm(v, done) {
    const bg = modal(`<h3>${v ? 'Edit video' : 'Upload new video'}</h3>
      <form>
        <label>Title<input type="text" name="title" required maxlength="140" value="${esc(v && v.title)}"></label>
        <label>Description<textarea name="description">${esc(v && v.description)}</textarea></label>
        <label>Category<select name="category">${catOptions(v && v.category)}</select></label>
        ${uploadField({ name: 'video_url', label: 'Video file (MP4 recommended)', accept: 'video/*', folder: 'videos', kind: 'video', url: v && v.video_url })}
        ${uploadField({ name: 'thumbnail_url', label: 'Thumbnail image (optional)', accept: 'image/*', folder: 'thumbnails', kind: 'image', url: v && v.thumbnail_url })}
        <label class="check"><input type="checkbox" name="published" ${!v || v.published ? 'checked' : ''}> Show on website (published)</label>
        <div class="row"><button class="btn primary save" type="submit">Save</button><button class="btn" type="button" data-cancel>Cancel</button></div>
      </form>`);
    const form = $('form', bg);
    wireUploads(form);
    form.querySelector('[data-cancel]').onclick = () => closeForm(bg, form, false);
    form.onsubmit = async (e) => {
      e.preventDefault();
      if (!form.video_url.value) return toast('Please upload a video file first.', 'err');
      const payload = {
        title: form.elements.title.value.trim(),
        description: form.description.value.trim(),
        category: form.category.value || null,
        video_url: form.video_url.value,
        thumbnail_url: form.thumbnail_url.value || null,
        published: form.published.checked
      };
      const btn = form.querySelector('.save');
      btn.disabled = true; btn.textContent = 'Saving…';
      try {
        let r;
        if (v) r = await sb.from('videos').update(payload).eq('id', v.id);
        else r = await sb.from('videos').insert({ ...payload, sort_order: await nextTopOrder('videos') });
        if (r.error) throw r.error;
        closeForm(bg, form, true);
        toast('Video saved');
        done();
      } catch (err) {
        toast(errMsg(err), 'err');
        btn.disabled = false; btn.textContent = 'Save';
      }
    };
  }

  /* ---------- projects ---------- */
  function pageProjects() {
    return listPage({
      table: 'projects', singular: 'project', plural: 'projects',
      thumb: (p) => {
        const img = p.cover_image_url || ((p.media || []).find((m) => m.type === 'image') || {}).url;
        return thumbEl(img, null);
      },
      files: (p) => [p.cover_image_url, ...(p.media || []).map((m) => m.url)],
      form: projectForm
    });
  }

  function projectForm(p, done) {
    const bg = modal(`<h3>${p ? 'Edit project' : 'Add new project'}</h3>
      <form>
        <label>Project title<input type="text" name="title" required maxlength="140" value="${esc(p && p.title)}"></label>
        <label>Description<textarea name="description">${esc(p && p.description)}</textarea></label>
        <label>Category<select name="category">${catOptions(p && p.category)}</select></label>
        ${uploadField({ name: 'cover_image_url', label: 'Cover image', accept: 'image/*', folder: 'projects', kind: 'image', url: p && p.cover_image_url })}
        <div class="upl"><span>More images &amp; videos (you can select several)</span>
          <input type="file" id="mediaFile" accept="image/*,video/*" multiple>
          <div class="bar"><i></i></div><small class="status" id="mediaStatus"></small>
          <div class="mediaitems" id="mediaItems"></div></div>
        <label class="check"><input type="checkbox" name="published" ${!p || p.published ? 'checked' : ''}> Show on website (published)</label>
        <div class="row"><button class="btn primary save" type="submit">Save</button><button class="btn" type="button" data-cancel>Cancel</button></div>
      </form>`);
    const form = $('form', bg);
    wireUploads(form);
    const media = [...((p && p.media) || [])];
    const items = $('#mediaItems', bg);
    const draw = () => {
      items.innerHTML = media.map((m, i) => `<div class="mi">${m.type === 'video'
        ? `<video muted preload="metadata" src="${esc(m.url)}#t=0.5"></video>`
        : `<img src="${esc(m.url)}" alt="">`}<button type="button" data-i="${i}" title="Remove">×</button></div>`).join('');
    };
    draw();
    items.onclick = (e) => {
      const b = e.target.closest('button');
      if (!b) return;
      const [rm] = media.splice(+b.dataset.i, 1);
      form._old.push(rm.url);
      draw();
    };
    $('#mediaFile', bg).onchange = async (e) => {
      const files = [...e.target.files];
      if (!files.length) return;
      const bar = $('.bar i', e.target.parentNode);
      const status = $('#mediaStatus', bg);
      busy(form, 1);
      for (let k = 0; k < files.length; k++) {
        try {
          status.textContent = `Uploading ${k + 1} of ${files.length}… 0%`;
          const u = await uploadFile(files[k], 'projects', (pr) => { bar.style.width = pr + '%'; status.textContent = `Uploading ${k + 1} of ${files.length}… ${pr}%`; });
          media.push({ type: files[k].type.startsWith('video') ? 'video' : 'image', url: u });
          form._new.push(u);
          draw();
        } catch (err) { toast(errMsg(err), 'err'); }
      }
      status.textContent = 'Done ✓';
      bar.style.width = '0';
      e.target.value = '';
      busy(form, -1);
    };
    form.querySelector('[data-cancel]').onclick = () => closeForm(bg, form, false);
    form.onsubmit = async (e) => {
      e.preventDefault();
      const payload = {
        title: form.elements.title.value.trim(),
        description: form.description.value.trim(),
        category: form.category.value || null,
        cover_image_url: form.cover_image_url.value || null,
        media,
        published: form.published.checked
      };
      const btn = form.querySelector('.save');
      btn.disabled = true; btn.textContent = 'Saving…';
      try {
        let r;
        if (p) r = await sb.from('projects').update(payload).eq('id', p.id);
        else r = await sb.from('projects').insert({ ...payload, sort_order: await nextTopOrder('projects') });
        if (r.error) throw r.error;
        closeForm(bg, form, true);
        toast('Project saved');
        done();
      } catch (err) {
        toast(errMsg(err), 'err');
        btn.disabled = false; btn.textContent = 'Save';
      }
    };
  }

  /* ---------- categories ---------- */
  async function pageCategories() {
    await loadCats();
    $('#page').innerHTML = `
      <div class="panel"><h3>Add category</h3>
        <form id="catForm" class="row"><input type="text" name="name" placeholder="e.g. Logo Design" required maxlength="40" style="flex:1;min-width:200px;margin:0">
        <button class="btn primary" type="submit">Add</button></form></div>
      <div class="panel list"><h3>Your categories</h3>
        ${cats.length ? cats.map((c) => `<div class="item" data-id="${c.id}"><div class="info"><b>${esc(c.name)}</b></div>
          <div class="actions"><button class="btn sm" data-a="rename">Rename</button><button class="btn sm danger" data-a="del">Delete</button></div></div>`).join('')
          : '<p class="empty">No categories yet.</p>'}
      </div>`;
    $('#catForm').onsubmit = async (e) => {
      e.preventDefault();
      const name = e.target.name.value.trim();
      if (!name) return;
      const max = cats.reduce((m, c) => Math.max(m, c.sort_order), 0);
      const { error } = await sb.from('categories').insert({ name, sort_order: max + 1 });
      if (error) return toast(error.code === '23505' ? 'That category already exists.' : errMsg(error), 'err');
      toast('Category added');
      route();
    };
    $('#page .list').onclick = async (e) => {
      const b = e.target.closest('button[data-a]');
      if (!b) return;
      const c = cats.find((x) => x.id === b.closest('.item').dataset.id);
      try {
        if (b.dataset.a === 'rename') {
          const name = (prompt('New name for this category:', c.name) || '').trim();
          if (!name || name === c.name) return;
          const r = await sb.from('categories').update({ name }).eq('id', c.id);
          if (r.error) throw r.error;
          await sb.from('videos').update({ category: name }).eq('category', c.name);
          await sb.from('projects').update({ category: name }).eq('category', c.name);
          toast('Category renamed');
        } else {
          const [v, p] = await Promise.all([
            sb.from('videos').select('*', { count: 'exact', head: true }).eq('category', c.name),
            sb.from('projects').select('*', { count: 'exact', head: true }).eq('category', c.name)
          ]);
          const used = (v.count || 0) + (p.count || 0);
          if (used) return toast(`“${c.name}” is used by ${used} item(s). Move them to another category first.`, 'err');
          if (!confirm(`Delete category “${c.name}”?`)) return;
          const r = await sb.from('categories').delete().eq('id', c.id);
          if (r.error) throw r.error;
          toast('Category deleted');
        }
        route();
      } catch (err) { toast(errMsg(err), 'err'); }
    };
  }

  /* ---------- website content ---------- */
  async function pageContent() {
    const s = await getSettings();
    const exp = Array.isArray(s.experience) ? s.experience : [];
    $('#page').innerHTML = `<form id="contentForm">
      <div class="panel"><h3>Profile</h3>
        <label>Your name<input type="text" name="site_name" value="${esc(s.site_name)}"></label>
        ${uploadField({ name: 'profile_image_url', label: 'Profile picture', accept: 'image/*', folder: 'profile', kind: 'image', url: s.profile_image_url })}
      </div>
      <div class="panel"><h3>Hero section</h3>
        <label>Heading<input type="text" name="hero_heading" value="${esc(s.hero_heading)}"></label>
        <label>Subtitle<textarea name="hero_subtitle" style="min-height:80px">${esc(s.hero_subtitle)}</textarea></label>
        <div class="grid2">
          <label>Main button text<input type="text" name="hero_button_text" value="${esc(s.hero_button_text)}"></label>
          <label>Contact button text<input type="text" name="contact_button_text" value="${esc(s.contact_button_text)}"></label>
        </div></div>
      <div class="panel"><h3>About me</h3>
        <label>Section title<input type="text" name="about_title" value="${esc(s.about_title)}"></label>
        <label>About text<textarea name="about_text" style="min-height:160px">${esc(s.about_text)}</textarea></label></div>
      <div class="panel"><h3>Experience</h3><div id="expRows"></div>
        <button type="button" class="btn sm" id="addExp">＋ Add experience</button></div>
      <button class="btn primary save" type="submit">Save changes</button></form>`;
    const form = $('#contentForm');
    wireUploads(form);
    const rows = $('#expRows');
    const addRow = (e) => {
      const d = document.createElement('div');
      d.className = 'exprow';
      d.innerHTML = `<div class="grid2"><label>Role<input type="text" data-k="role" value="${esc(e.role)}"></label>
        <label>Company / client<input type="text" data-k="company" value="${esc(e.company)}"></label></div>
        <label>Period (e.g. 2023 – Present)<input type="text" data-k="period" value="${esc(e.period)}"></label>
        <label>Description<textarea data-k="description" style="min-height:70px">${esc(e.description)}</textarea></label>
        <button type="button" class="btn sm danger" data-rm>Remove</button>`;
      rows.appendChild(d);
    };
    exp.forEach(addRow);
    $('#addExp').onclick = () => addRow({});
    rows.onclick = (e) => { if (e.target.matches('[data-rm]')) e.target.closest('.exprow').remove(); };
    form.onsubmit = async (e) => {
      e.preventDefault();
      const experience = [...rows.querySelectorAll('.exprow')].map((r) => {
        const o = {};
        r.querySelectorAll('[data-k]').forEach((i) => { o[i.dataset.k] = i.value.trim(); });
        return o;
      }).filter((o) => o.role || o.company || o.description);
      const btn = form.querySelector('.save');
      btn.disabled = true; btn.textContent = 'Saving…';
      try {
        await saveSettings({
          site_name: form.site_name.value.trim(),
          profile_image_url: form.profile_image_url.value || null,
          hero_heading: form.hero_heading.value.trim(),
          hero_subtitle: form.hero_subtitle.value.trim(),
          hero_button_text: form.hero_button_text.value.trim(),
          contact_button_text: form.contact_button_text.value.trim(),
          about_title: form.about_title.value.trim(),
          about_text: form.about_text.value.trim(),
          experience
        });
        await removeFiles(form._old);
        form._old = []; form._new = [];
        toast('Website content saved');
      } catch (err) { toast(errMsg(err), 'err'); }
      btn.disabled = false; btn.textContent = 'Save changes';
    };
  }

  /* ---------- social & contact ---------- */
  async function pageSocial() {
    const s = await getSettings();
    $('#page').innerHTML = `<form id="socialForm">
      <div class="panel"><h3>Social media</h3>
        <label>YouTube URL<input type="url" name="youtube_url" placeholder="https://youtube.com/@yourchannel" value="${esc(s.youtube_url)}"></label>
        <label>TikTok URL<input type="url" name="tiktok_url" placeholder="https://tiktok.com/@yourname" value="${esc(s.tiktok_url)}"></label>
        <label>Instagram URL<input type="url" name="instagram_url" placeholder="https://instagram.com/yourname" value="${esc(s.instagram_url)}"></label>
        <label>WhatsApp number <small>(with country code, e.g. 8801XXXXXXXXX)</small><input type="tel" name="whatsapp_number" value="${esc(s.whatsapp_number)}"></label></div>
      <div class="panel"><h3>Contact information</h3>
        <label>Email address<input type="email" name="email" value="${esc(s.email)}"></label>
        <label>Phone number <small>(optional)</small><input type="tel" name="contact_phone" value="${esc(s.contact_phone)}"></label>
        <label>Location <small>(optional)</small><input type="text" name="contact_location" value="${esc(s.contact_location)}"></label></div>
      <button class="btn primary save" type="submit">Save changes</button></form>`;
    const form = $('#socialForm');
    form.onsubmit = async (e) => {
      e.preventDefault();
      for (const k of ['youtube_url', 'tiktok_url', 'instagram_url']) {
        if (!isUrl(form[k].value.trim())) return toast('Links must start with https://', 'err');
      }
      const btn = form.querySelector('.save');
      btn.disabled = true; btn.textContent = 'Saving…';
      try {
        const v = (k) => form[k].value.trim() || null;
        await saveSettings({
          youtube_url: v('youtube_url'), tiktok_url: v('tiktok_url'), instagram_url: v('instagram_url'),
          whatsapp_number: v('whatsapp_number'), email: v('email'),
          contact_phone: v('contact_phone'), contact_location: v('contact_location')
        });
        toast('Contact & social links saved');
      } catch (err) { toast(errMsg(err), 'err'); }
      btn.disabled = false; btn.textContent = 'Save changes';
    };
  }

  /* ---------- account ---------- */
  async function pageAccount() {
    const { data } = await sb.auth.getUser();
    $('#page').innerHTML = `<div class="panel"><h3>Change password</h3>
      <p class="hint" style="margin-bottom:14px">Signed in as ${esc(data.user && data.user.email)}</p>
      <form id="pwForm">
        <label>New password <small>(at least 8 characters)</small><input type="password" name="pw" minlength="8" required autocomplete="new-password"></label>
        <label>Confirm new password<input type="password" name="pw2" minlength="8" required autocomplete="new-password"></label>
        <button class="btn primary save" type="submit">Update password</button></form></div>`;
    $('#pwForm').onsubmit = async (e) => {
      e.preventDefault();
      const f = e.target;
      if (f.pw.value !== f.pw2.value) return toast('Passwords do not match.', 'err');
      const { error } = await sb.auth.updateUser({ password: f.pw.value });
      if (error) return toast(errMsg(error), 'err');
      f.reset();
      toast('Password updated');
    };
  }

  /* ---------- boot ---------- */
  (async function init() {
    try {
      const { data } = await sb.auth.getSession();
      if (data.session && (await isAdmin())) return showApp();
      if (data.session) await sb.auth.signOut();
    } catch (e) { /* fall through to login */ }
    showLogin();
  })();
})();
